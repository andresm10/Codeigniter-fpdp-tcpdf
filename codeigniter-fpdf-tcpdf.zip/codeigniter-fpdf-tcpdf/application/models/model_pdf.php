<?php

class Model_pdf extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function getUsuarios() {       	   
        $this->db->select('*');
        $q = $this->db->get('usuarios');
        return $q->result();
        $q->free_result();
    }

}

?>
