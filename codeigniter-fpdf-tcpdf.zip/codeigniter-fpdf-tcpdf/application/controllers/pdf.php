<?php

class Pdf extends CI_Controller {
	
	public function __construct() {
        parent::__construct();
        $this->load->model('model_pdf', 'pdf');
    }
	
	public function index()
	{
		$this->load->view('fpdf-tcpdf');
	}
	
	public function exportarFpdf(){
		$data["usuarios"] = $this->pdf->getUsuarios();
        $this->load->vars($data);
        $this->load->view("reporte-fpdf");	
	}
	
	public function exportarTcpdf(){
		$data["usuarios"] = $this->pdf->getUsuarios();
        $this->load->vars($data);
        $this->load->view("reporte-tcpdf");	
	}
}