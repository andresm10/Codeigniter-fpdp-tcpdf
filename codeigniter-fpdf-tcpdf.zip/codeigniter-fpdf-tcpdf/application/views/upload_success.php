<head>
<title>Formulario de Carga</title>
</head>
<body>
<h3>Su archivo fue exitosamente subido!</h3>
<ul>
<?php /*?><?php foreach($upload_data as $item => $value):?>
<li><?php echo $item; ?>: <?php echo $value;?></li>
<?php endforeach; ?>
</ul><?php */?>
<?php $i=0; 
foreach($upload_data as $item):
$i++;
	if($i<2){
	echo $item; 
	}
endforeach; ?>
</ul>
<p><?php echo anchor('upload', 'Subir otro archivo!'); ?></p>
</body>
</html>